﻿using UnityEngine;

public class GameOver : MonoBehaviour
{
    public FinishLine finishLine;

    private void OnTriggerEnter(Collider other)
    {
        if (other.tag.Equals("Player"))
            finishLine.LevelComplete();
    }
}
