﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerControler : MonoBehaviour
{
    public int mvmntSpeed = 10;
    public int jumpSpeed = 2;

    private void Update()
    {
        float forward = Input.GetAxis("Vertical");
        float horizontal = Input.GetAxis("Horizontal");
        float jump = Input.GetAxis("Jump");

        float forwardMovement = forward * mvmntSpeed * Time.deltaTime;
        float sidewaysMovement = horizontal * mvmntSpeed * Time.deltaTime;
        float upwardJump = jump * jumpSpeed * Time.deltaTime;

        transform.Translate(-forwardMovement, 0, sidewaysMovement);
        transform.Translate(0, upwardJump, 0);
    }
}
