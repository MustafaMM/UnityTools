﻿/*
 *This is the RedItemCollectable script. Whenever the player touches that item a few things happen:
 * First, time is slowed for everything in the scene.
 * Second, particle effect plays.
 * Third, obstacles are slowed down for a few seconds.
 * Finally, obstacles return to normal speed.
 */
using System.Collections;
using UnityEngine;

public class RedItemScript : MonoBehaviour
{
    public TimeManagerScript timeManager;

    public ParticleSystem ps;
    ParticleSystem.EmissionModule em;
    ParticleSystem.MainModule main;

    //I initialize the arrays and fill them in the start method so that I can use the arrays in the coroutine.
    GameObject[] verticalGameObejctsToSlow;
    GameObject[] horizontalGameObejctsToSlow;


    private void Start()
    {
        verticalGameObejctsToSlow = GameObject.FindGameObjectsWithTag("VerticalObstacle");
        horizontalGameObejctsToSlow = GameObject.FindGameObjectsWithTag("HorizontalObstacle");
        //The emission module in the particle system (which is fancy for saying the emission in the ParticleSystem component of the Particle
        // System gameObject) is the smae as the one that we declared public variable. Basically we are saying to control the emission of
        //the gameObject that we specified.
        em = ps.emission;
        //Set the emission to false when we start playing. We will set it to true later.
        em.enabled = false;
        //Here I'm pretty much doing the same thing..If I dont have this line (and the "em=ps.emission;" line) then I'm  creating modules
        //instead of getting instances of the already created modules, which is what I should be doing because thats what we want to edit
        //the loop of.
        main = ps.main;
    }

    private void OnTriggerEnter(Collider other)
    {
        //If I destroy the gameObject then the coroutine wont execute, which means the obstacles wont return to normal speed.
        //Destroy(gameObject);
        //The 3 lines below get the position of the parent gameObject before I change its position, so that the particles later will
        //play on the original position of the gameObject (not the new position that is  (-10,-10,-10) ).
        float xPos = gameObject.transform.localPosition.x;
        float yPos = gameObject.transform.localPosition.y;
        float zPos = gameObject.transform.localPosition.z;
        //That is why I just put its position below the ground and I'll destroy it later after I finish the coroutine call.
        gameObject.transform.position = new Vector3(-10,-10,-10);
        //Set the position of the particle system, then enable it.
        ps.transform.SetPositionAndRotation(new Vector3(xPos, yPos + 1, zPos), Quaternion.identity);
        em.enabled = true;
        //Turn the looping off for the particle because if we dont do that, the particle system will play forever.
        main.loop = false;
        //The TimeDown method in the TimeManager script
        timeManager.TimeDown();
        ObstacleSlowDown();
    }

    private void ObstacleSlowDown()
    {
        //Just change the speed of all obstacles that move.

        for (int i = 0; i<horizontalGameObejctsToSlow.Length; i++)
        {
            horizontalGameObejctsToSlow[i].GetComponent<MovingObstacle>().mvmntSpeed = 5 ;
        }

        for (int i = 0; i < verticalGameObejctsToSlow.Length; i++)
        {
            verticalGameObejctsToSlow[i].GetComponent<VerticalMovingObstacle>().mvmntSpeed = 0.9f;
        }

        //After slowing the obstacles down, start the coroutine.
        StartCoroutine(ReturnToNormal());
    }

    IEnumerator ReturnToNormal()
    {
        //When the coroutine starts, wait for 5 seconds then return the obstacles back to normal speed. In other words the obstacles
        //will be in slow motion for 5 seconds, which is the power the red item collectable is supposed to do.
        yield return new WaitForSeconds(5);

        GoBackNormalSpeed();
    }

    private void GoBackNormalSpeed()
    {
        for (int i = 0; i < horizontalGameObejctsToSlow.Length; i++)
        {
            horizontalGameObejctsToSlow[i].GetComponent<MovingObstacle>().mvmntSpeed = 20;
        }

        for (int i = 0; i < verticalGameObejctsToSlow.Length; i++)
        {
            verticalGameObejctsToSlow[i].GetComponent<VerticalMovingObstacle>().mvmntSpeed = 1.2f;
        }

        //Now I can finally destroy the gameObject.
        Destroy(gameObject);
    }
}
