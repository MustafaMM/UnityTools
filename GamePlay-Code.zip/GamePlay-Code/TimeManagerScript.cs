﻿using UnityEngine;

public class TimeManagerScript : MonoBehaviour
{
    //Time will be 0.05 times as fast as it normally is (which is 1)
    public float timeSpeed = 0.05f;
    //Time will be slowed for 2 seconds
    public float timeDownLength = 1f;

    void Update()
    {
        Time.timeScale += (1f / timeDownLength) * Time.unscaledDeltaTime;
        Time.timeScale = Mathf.Clamp(Time.timeScale, 0f, 1f);
        //This line of fucking code was a misery. Apparently if I dont have this the the FixedUpdate framerate drops from 0.02 to 0.001
        //which, because in VerticalMovingObstacle script I use FixedUpdate, means that if I dont have this line then the vertical object
        //will pretty much hit the ground will just stop moving (if it does so mid air then it will fall because we have gravity not
        //because of the code).Basically without this line the whole VerticalMovingObstacle is doesnt work because FixedUpdate wont.
        //(which kinda makes sense now...)
        Time.fixedDeltaTime = 0.02f;
    }

    public void TimeDown()
    {
        //Slow down the time to 0.05 from 1. 
        Time.timeScale = timeSpeed;
        //Smoothen out the effect by making the interval at which the frames update equal to the time scale * 0.02 because 1/50= 0.0.2
        //and 50 frames per second is the standard.
        Time.fixedDeltaTime = Time.timeScale * 0.02f;
    }
}
