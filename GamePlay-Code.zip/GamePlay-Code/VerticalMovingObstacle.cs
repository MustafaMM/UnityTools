﻿using UnityEngine;

public class VerticalMovingObstacle : MonoBehaviour
{
    public float mvmntSpeed = 1.2f;

    //This is basically just initializing...the values here dont really matter.
    private Vector3 pos1 = new Vector3(0,30,0);
    private Vector3 pos2 = new Vector3(0, 25, 0);
    
    //For updates that affect the physics of the game I found it smoother to use FixedUpdate than only Update
    private void FixedUpdate()
    {
        float x = gameObject.transform.position.x;
        float z = gameObject.transform.position.z;

        pos1 = new Vector3(x, 35, z);
        pos2 = new Vector3(x, 25, z);

        transform.position = Vector3.Lerp(pos2, pos1, Mathf.PingPong(Time.time * mvmntSpeed, 1.0f));
    }
}
