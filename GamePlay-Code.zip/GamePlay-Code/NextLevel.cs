﻿using UnityEngine.SceneManagement;
using UnityEngine;

public class NextLevel : MonoBehaviour
{
    //I am just reloading the same scene 2 seconds after we reach the level complete point in the game. Two secnds specifically
    //is because thats what I chose. In the animation there is an event at the 2 second mark.
    public void NextLevelToLoad()
    {
        //0 because the index of the scene is 0. If you have multiple scenes there will be code instead of 0 inside of the brackets.
        SceneManager.LoadScene(0);
    }
}
