﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CollectablePickup : MonoBehaviour
{
    public int rotationSpeed = 220;

    void OnTriggerEnter(Collider other)
    {
        ScoreSys.theScore += 50;
        Destroy(gameObject);
    }

    public void Update()
    {
        //This rotates the object around the x,z axis.
        gameObject.transform.RotateAround(transform.localPosition, new Vector3(0,1,1), rotationSpeed * Time.deltaTime);
    }
}
