﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MovingObstacle : MonoBehaviour
{
    public int mvmntSpeed = 20;
    bool checker = true;

    private void Update()
    {
        if (checker)
            transform.Translate(Vector3.forward * mvmntSpeed * Time.deltaTime);
        else
            transform.Translate(Vector3.back * mvmntSpeed * Time.deltaTime);

        if (transform.position.z >= 10)
        {
            checker = false;
        }

        if (transform.position.z <= -14)
        {
            checker = true;
        }
    }
}
