﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FinishLine : MonoBehaviour
{
    //We want a reference to our UI. The UI that we will put in this slot is called "LevelCompletePanel" which can be found under 
    //TextCanvas in the hierarchy.
    public GameObject completeLevelUI;

    public void LevelComplete()
    {
        Debug.Log("Game Over");
        //The UI is set to false by default cause we dont want it to be automatically active when we start the game. We set it to true
        //only when we complete the level.
        completeLevelUI.SetActive(true);
    }
}
