﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;

public class SelectAllOfTag : ScriptableWizard
{
    public string selectedTag = "Choose Tag";

    [MenuItem("My Tools/Select All Of Tags...")]
    static void SelectAllOfTagWizard()
    {
        ScriptableWizard.DisplayWizard<SelectAllOfTag>("Select All Of Tags...", "Make Selection");
    }

    private void OnWizardCreate()
    {
        GameObject[] selectedTags = GameObject.FindGameObjectsWithTag(selectedTag);
        for(int i=0; i< selectedTags.Length; i++)
        {
            //This is just for reference dw about it.
            Debug.Log(selectedTags[i]);
        }
        Selection.objects = selectedTags;
    }
}
