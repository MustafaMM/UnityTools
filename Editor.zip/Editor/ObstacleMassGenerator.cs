﻿/*
 * This class will basically make an option such that user enters how many copies of each obstacle they want, and the tool will
 * create the obstacles with all the required properties. All thats left is for the user to place them where they want.
 */
using UnityEngine;
using UnityEditor;

public class ObstacleMassGenerator : ScriptableWizard
{
    public int verticalObstacleCount;
    public int horizontalObstacleCount;
    public int staticObstacleCount;

    [MenuItem("My Tools/Generate Obstacles...")]
    static void CreateMethod()
    {
        ScriptableWizard.DisplayWizard<ObstacleMassGenerator>("Obstacle Mass Generator", "Create");
    }
    private void OnWizardCreate()
    {
        //Three loops, each one to create the required no. of duplicates (which we get from user by 
        //just declaring the variables public) for the associated obstacle.

        //The three loops are similar so I'll comment only one.
        for(int i = 0; i<verticalObstacleCount; i++)
        {
            //This is an array that gets the number of already existing vertical obstacles, so that when we add 1 to the 
            //length of this array we get the number of the gameObject we are creating now. We then add that to the name.
            GameObject[] existingVerticalObstacles = GameObject.FindGameObjectsWithTag("VerticalObstacle");
            GameObject gameObject = GameObject.CreatePrimitive(PrimitiveType.Cube);
            gameObject.tag = "VerticalObstacle";
            gameObject.name = "Vertical Obstacle " + (existingVerticalObstacles.Length + 1);
            gameObject.AddComponent<Rigidbody>();
            gameObject.AddComponent<VerticalMovingObstacle>();
            //This is basically the size of the obstacle. Obviously each obstacle will have a different size.
            gameObject.transform.localScale = new Vector3(5, 50, 30);
            gameObject.GetComponent<Rigidbody>().mass = 1000;
            //Line below basically restricts the movement of the obstacle to only horizontaly, and also no rotation.
            gameObject.GetComponent<Rigidbody>().constraints = RigidbodyConstraints.FreezePositionX | RigidbodyConstraints.FreezePositionZ | RigidbodyConstraints.FreezeRotationX | RigidbodyConstraints.FreezeRotationY | RigidbodyConstraints.FreezeRotationZ;
        }

        for(int i = 0; i<horizontalObstacleCount; i++)
        {
            GameObject[] existingHorizontalObstacle = GameObject.FindGameObjectsWithTag("HorizontalObstacle");
            GameObject gameObject = GameObject.CreatePrimitive(PrimitiveType.Cube);
            gameObject.tag = ("HorizontalObstacle");
            gameObject.name = "Horizontal Obstacle " + (existingHorizontalObstacle.Length + 1);
            gameObject.AddComponent<Rigidbody>();
            gameObject.AddComponent<MovingObstacle>();
            gameObject.transform.localScale = new Vector3(1, 0.5f, 5);
            gameObject.GetComponent<Rigidbody>().mass = 500;
            //Keep in mind that here and in the staticObstacleCount loop I dont freez Y Position because even though I dont need
            //it in movement, I still need it for the physics so that for example if object is a little above ground it will fall back.
            gameObject.GetComponent<Rigidbody>().constraints = RigidbodyConstraints.FreezePositionX | RigidbodyConstraints.FreezeRotationX | RigidbodyConstraints.FreezeRotationY | RigidbodyConstraints.FreezeRotationZ;
        }

        for (int i = 0; i<staticObstacleCount; i++)
        {
            GameObject[] existingStaticObstacles = GameObject.FindGameObjectsWithTag("StaticObstacle");
            GameObject gameObject = GameObject.CreatePrimitive(PrimitiveType.Cube);
            gameObject.tag = ("StaticObstacle");
            gameObject.name = "Static Obstacle " + (existingStaticObstacles.Length + 1);
            gameObject.AddComponent<Rigidbody>();
            gameObject.transform.localScale = new Vector3(1,0.5f,5);
            gameObject.GetComponent<Rigidbody>().mass = 500;
            gameObject.GetComponent<Rigidbody>().constraints = RigidbodyConstraints.FreezePositionX | RigidbodyConstraints.FreezePositionZ | RigidbodyConstraints.FreezeRotationX | RigidbodyConstraints.FreezeRotationY | RigidbodyConstraints.FreezeRotationZ;
        }
    }
}
