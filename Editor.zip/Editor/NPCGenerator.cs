﻿/*
 * This script will basically allow you to mass generate NPC's. The way it will be used is the user will choose the gender, the 
 * animation they want, and how many duplicates of the model they want. For example you can specify 5 duplicates, Male, Clapping animation
 * and the program will create 5 male gameobjects that have all the necessary components, pretty much ready to use. Just position the NPC
 * wherever you want and when you click play everything will function well. The best way to use is to make for example 3 copies of male 
 * clapping, then 7 copies of male cheering, then 5 copies of female clapping, then 3 copies of female cheering to create varaiety.
 * 
 * To use this feature just go to "My Tools" from the menu bar, and choose "Generate NPC's".
 */
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;

public class NPCGenerator : ScriptableWizard
{

    public int SpecifyDuplicateAmount = 1;
    public enum Gender { Male, Female}
    public Gender SelectGender;
    public enum Cheer { Clap, Cheer}
    public Cheer SelectCheer;

    [MenuItem("My Tools/Create NPC's...")]
    static void CreateClick()
    {
        ScriptableWizard.DisplayWizard<NPCGenerator>("Create");
    }
    private void OnWizardCreate()
    {
        string genderSelected = SelectGender.ToString();
        Debug.Log(genderSelected);

        //I have two animations, so the code below allows me to use a string in the runtimeAnimatorController later.
        string animationPlaceholder = SelectCheer.ToString();
        string animationToDisplay = "Default";
        if(animationPlaceholder == "Clap")
        {
            animationToDisplay = "MaleIdleCheer";
        }
        else
        {
            animationToDisplay = "FemaleCheer";
        }

        //Take in an int number and generate said number of duplicates. The code below will make the parent GameObject
        for (int i = 0; i< SpecifyDuplicateAmount; i++)
        {
            if(genderSelected == "Male")
            {
                GameObject parentGameObject = new GameObject();
                parentGameObject.name = "Male NPC" + (i + 1);
                parentGameObject.tag = "MaleNPC";
                //Add the components that all NPC's will have
                parentGameObject.AddComponent<Rigidbody>();
                //I freeze the rotation in the x,y,z because if i dont the model will instantly fall to the side.
                parentGameObject.GetComponent<Rigidbody>().constraints = RigidbodyConstraints.FreezeRotationX | RigidbodyConstraints.FreezeRotationY | RigidbodyConstraints.FreezeRotationZ;
                parentGameObject.AddComponent<CapsuleCollider>();
                parentGameObject.GetComponent<CapsuleCollider>().height = 2;
                parentGameObject.GetComponent<CapsuleCollider>().center = new Vector3(0,1,0);

                //Now the code below basically creates the GFX child GameObject.
               
                //Find the prefab (or asset) and change it into a gameobject
                Object GFX = AssetDatabase.LoadAssetAtPath("Assets/Male.fbx", typeof(GameObject));
                GameObject MaleGFX = (GameObject)Instantiate(GFX, new Vector3(0, 0, 0), Quaternion.identity);
                //Set the parent of the GFX to the parentGameObject we made above.
                MaleGFX.transform.parent = parentGameObject.transform;
                MaleGFX.name = "Male GFX";
                //Set the animation. Keep in mind that since I used Resources.Load that means the animations have to be in a file named "Resources"
                MaleGFX.GetComponent<Animator>().runtimeAnimatorController = Instantiate(Resources.Load(animationToDisplay)) as RuntimeAnimatorController;
               
            }   
            else
            {
                //If its not a male, then now we are creating the parentGameObject  which is exactly same as male except the name
                GameObject parentGameObject = new GameObject();
                parentGameObject.name = "Female NPC" + (i + 1);
                parentGameObject.tag = "FemaleNPC";
                //Add the components that all NPC's will have
                parentGameObject.AddComponent<Rigidbody>();
                parentGameObject.GetComponent<Rigidbody>().constraints = RigidbodyConstraints.FreezeRotationX | RigidbodyConstraints.FreezeRotationY | RigidbodyConstraints.FreezeRotationZ;
                parentGameObject.AddComponent<CapsuleCollider>();
                parentGameObject.GetComponent<CapsuleCollider>().height = 2;
                parentGameObject.GetComponent<CapsuleCollider>().center = new Vector3(0, 1, 0);

                //And now the code below is making the GFX for the female gameObject.
            
                //Find the prefab and change it into a gameobject
                Object GFX = AssetDatabase.LoadAssetAtPath("Assets/Female.fbx", typeof(GameObject));
                GameObject FemaleGFX = (GameObject)Instantiate(GFX, new Vector3(0, 0, 0), Quaternion.identity);
                FemaleGFX.transform.parent = parentGameObject.transform;
                FemaleGFX.name = "Female GFX";
                //Set the animation
                FemaleGFX.GetComponent<Animator>().runtimeAnimatorController = Instantiate(Resources.Load(animationToDisplay)) as RuntimeAnimatorController;
            }
        }
        
    }


}
