﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;

public class CollectableMassGenerator : ScriptableWizard
{
    //The public variables below will be displayed when we go to "My Tools" and click "Create Collectables"
    public int DuplicateCount = 1;

    public enum CollectableType { Gold, Red}
    public CollectableType collectableType;

    [MenuItem("My Tools/Create Collectables...")]
    static void CreateButton()
    {
        ScriptableWizard.DisplayWizard<CollectableMassGenerator>("Creating Gold Coins Collectables", "Create");
    }
    private void OnWizardCreate()
    {
        //The two lines below are to get the material asset for the gold coins.
        Object collectableColor = AssetDatabase.LoadAssetAtPath<Material>("Assets/CollectableColor.mat");
        Material goldMat = (Material)collectableColor;

        Object redItemPickup = AssetDatabase.LoadAssetAtPath<Material>("Assets/SlowDownObstacles.mat");
        Material redMat = (Material)redItemPickup;

        //This is to get the TimeManager prefab asset and use it to link the TimeManagerScript to the RedItemScript whenever
        //I create a new RedItem.
        Object redItemAsset = AssetDatabase.LoadAssetAtPath<TimeManagerScript>("Assets/TimeManager.prefab");
        TimeManagerScript redItemTimeManager = (TimeManagerScript)redItemAsset;

        for (int i = 0; i<DuplicateCount; i++)
        {
            //Update the list of existing collectables every iteration so that later when I add the length of the list as a number to 
            //the name of the collectable the list will be updated to include the previous iteration of the loop.
            GameObject[] existingCollectables = GameObject.FindGameObjectsWithTag("Collectable");
            GameObject[] existingRedItems = GameObject.FindGameObjectsWithTag("ItemRed");
            GameObject gameObject = GameObject.CreatePrimitive(PrimitiveType.Cylinder);
            gameObject.transform.localScale = new Vector3(0.62f, 0.08f, 0.63f);

            //Only apply the gold material to the collectable if its a gold coin collectable. I plan on making other types of collectables
            if (collectableType.ToString().Equals("Gold"))
            {
                gameObject.tag = "Collectable";
                gameObject.AddComponent<CollectablePickup>();
                gameObject.name = "Collectable " + (existingCollectables.Length + 1);
                gameObject.GetComponent<Renderer>().material = goldMat;
                gameObject.GetComponent<CapsuleCollider>().isTrigger = true;
            }
            else if (collectableType.ToString().Equals("Red"))
            {
                Object particleSys = AssetDatabase.LoadAssetAtPath<ParticleSystem>("Assets/Particle System.prefab");
                ParticleSystem particlesPlayed = Instantiate(particleSys, new Vector3(gameObject.transform.localPosition.x, gameObject.transform.localPosition.y, gameObject.transform.localPosition.z), Quaternion.identity) as ParticleSystem;

                //Ok this was trolling......You HAVE to have added the RedItemScript before adding the redItemTimeManager...(which
                //again, makes sense now..). Basically you HAVE to have line 54 before line 56
                gameObject.AddComponent<RedItemScript>();
                gameObject.GetComponent<RedItemScript>().ps = particlesPlayed;
                particlesPlayed.transform.SetParent(gameObject.transform);
                gameObject.tag = "ItemRed";
                gameObject.GetComponent<RedItemScript>().timeManager = redItemTimeManager;
                gameObject.GetComponent<CapsuleCollider>().isTrigger = true;
                gameObject.name = "RedItem " + (existingRedItems.Length + 1);
                gameObject.GetComponent<Renderer>().material = redMat;
            }

        }
    }
}
