﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;

public class CreateGameObject : ScriptableWizard
{
    public string characterName = "Choose name";
    public int characterSpeed = 10;
    public int characterJumpSpeed = 2;

    [MenuItem("My Tools/Create Player")]
    static void InitializeTheWizard()
    {
        ScriptableWizard.DisplayWizard<CreateGameObject>("Creating A Player", "Create");
    }

    void OnWizardCreate()
    {
        CreateANewGameObject(characterName, characterSpeed, characterJumpSpeed);
    }

    void CreateANewGameObject( string name, int chosenSpeed, int chosenJumpSpeed)
    {
        GameObject cube = GameObject.CreatePrimitive(PrimitiveType.Cube);
        cube.name = name;
        cube.AddComponent<Rigidbody>();
        PlayerControler playerControler = cube.AddComponent<PlayerControler>();
        playerControler.mvmntSpeed = chosenSpeed;
        playerControler.jumpSpeed = chosenJumpSpeed;
        cube.transform.position = new Vector3((float)482.5, (float)2.17, (float)-3.4);
    }
}
